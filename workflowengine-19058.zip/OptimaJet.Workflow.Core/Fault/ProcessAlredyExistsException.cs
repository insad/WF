﻿using System;

namespace OptimaJet.Workflow.Core.Fault
{
    public class ProcessAlredyExistsException : Exception
    {
    }
}
