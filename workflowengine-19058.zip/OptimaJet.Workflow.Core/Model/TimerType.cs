﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OptimaJet.Workflow.Core.Model
{
    public enum TimerType
    {
        ByProcessInstance,
        ByProcessType
    }
}
