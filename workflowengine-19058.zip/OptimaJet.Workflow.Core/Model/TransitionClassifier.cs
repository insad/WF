﻿namespace OptimaJet.Workflow.Core.Model
{
    public enum TransitionClassifier
    {
        NotSpecified, 
        Direct,
        Reverse
    }
}
