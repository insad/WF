﻿using System;

namespace OptimaJet.Workflow.Core.Model
{
    public enum ParameterPurpose
    {
        Temporary, Persistence, System
    }
}
