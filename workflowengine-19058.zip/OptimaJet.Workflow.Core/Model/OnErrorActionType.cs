﻿namespace OptimaJet.Workflow.Core.Model
{
    public enum OnErrorActionType
    {
        SetActivity
    }
}
