﻿namespace OptimaJet.Common
{
    public class GlobalSettings
    {
        
    }
}